public  class Rook extends ChessPiece {
    public Rook(String color) {
        super( color );
    }

    @Override
    public String getColor() {
        return color;
    }

    @Override
    public boolean canMoveToPosition(ChessBoard chessBoard, int line, int column, int toLine, int toColumn) {
        if (checkPos( line ) && checkPos( column ) && checkPos( toLine ) && checkPos( toColumn )) {
            if (column == toColumn) {
                for (int i = getMin( line, toLine ); i < getMax( line, toLine ); i++) {
                    if (chessBoard.board[i][column] != null) {
                    } else if (chessBoard.board[i][column].getColor().equals( this.color ) && i == toLine)
                        return false;
                    else if (!chessBoard.board[i][column].getColor().equals( this.color ) && i == toLine)
                        return false;
                    else if (i != toLine && i != line)
                        return false;
                }
            }
            if (chessBoard.board[toLine][column] != null) {
                if (chessBoard.board[toLine][column].getColor().equals( this.color ) && chessBoard.board[toLine][column] != this) {
                    return false;
                } else
                    return !chessBoard.board[toLine][column].getColor().equals( this.color ) && chessBoard.board[toLine][column] != this;
            } else return true;
        } else return false;
    }

    @Override
    public String getSymbol() {
        return "R";
    }

    public int getMax(int a, int b) {
        return Math.max( a, b );
    }

    public int getMin(int a, int b) {
        return Math.min( a, b );
    }

    public boolean checkPos(int pos) {
        return pos >= 0 && pos <= 7;
    }
}


