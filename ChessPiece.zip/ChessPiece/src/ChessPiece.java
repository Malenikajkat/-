public abstract class ChessPiece {
    public boolean check;
    String color;
    boolean chek = true;

    public ChessPiece(String color) {
        this.color = color;
    }
    public abstract  String getColor();
    public abstract boolean canMoveToPosition(ChessBoard chessBoard, int line, int column, int toLine, int toColumn);
    public abstract String getSymbol();
    protected boolean checkPos(int pas){
        return pas >= 0 && pas <=7;
    }
    protected int getMax(int a, int b){
        return Math.max( a, b );
    }
    protected int getMin(int a, int b){
        return Math.min( a, b );
    }
}
